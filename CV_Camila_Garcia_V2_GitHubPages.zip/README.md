# 🌷 CV & Portafolio — Camila Garcia

CV web preparado para publicarse con **GitHub Pages**.

## 🚀 Publicarlo en GitHub Pages

1. Entra a GitHub y crea un repositorio nuevo.
2. Ponle un nombre como `cv-camila-garcia`.
3. Sube el archivo `index.html`.
4. Entra a **Settings → Pages**.
5. En **Build and deployment**, selecciona:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
6. Presiona **Save**.
7. GitHub generará tu página.

## ✏️ Editarlo después

No necesitas volver a generar el archivo.

Desde GitHub:

**Repositorio → index.html → ✏️ Edit → modificar → Commit changes**

GitHub Pages actualizará la página automáticamente.

## 📸 Agregar una foto

Puedes subir una imagen al mismo repositorio, por ejemplo:

`foto-camila.jpg`

Después puedes reemplazar:

```html
<div class="initials">CG</div>
```

por:

```html
<img src="foto-camila.jpg" alt="Camila Garcia">
```

## 📁 Agregar proyectos

Dentro de la sección `<!-- PROYECTOS -->` puedes duplicar una tarjeta para cada proyecto.

## 🔗 Agregar redes sociales

Puedes añadir enlaces de LinkedIn, Instagram o GitHub dentro de la sección de contacto.

## 💡 Importante

El archivo está hecho en un solo HTML y no depende de servidores, bases de datos ni programas externos. Esto facilita su edición y publicación en GitHub Pages.
